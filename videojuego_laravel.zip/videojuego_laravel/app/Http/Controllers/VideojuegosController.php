<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Videojuegos;

class VideojuegosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $videojuegos = Videojuegos::all();
        return $videojuegos;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $videojuego = new Videojuegos();
        $videojuego -> nombre = $request -> nombre;
        $videojuego -> descripcion = $request -> descripcion;
        $videojuego -> fecha_lanzamiento = $request -> fecha_lanzamiento;
        $videojuego -> genero = $request -> genero;
        $videojuego -> plataforma = $request -> plataforma;
        $videojuego ->save();
        $videoJuegos = Videojuegos::all();
        return $videoJuegos;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //solo busca de a uno, es la diferencia de index
        $videojuego = Videojuegos::find($id);
        return $videojuego;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $videojuego = Videojuegos::find($id);
        $videojuego -> nombre = $request -> nombre;
        $videojuego -> descripcion = $request -> descripcion;
        $videojuego -> fecha_lanzamiento = $request -> fecha_lanzamiento;
        $videojuego -> genero = $request -> genero;
        $videojuego ->plataforma =  $request-> plataforma;
        $videojuego ->save();
        $videoJuegos = Videojuegos::all();
        return $videoJuegos;
        }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $videojuego = Videojuegos::find($id);
        $videojuego->delete();
    }
}
